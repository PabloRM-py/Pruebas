# -*- coding: utf-8 -*-
"""
Created on Fri Nov 11 12:04:39 2022

@author: Pablo
"""

import numpy as np 

import matplotlib.pyplot as plt
import matplotlib.pylab as pylab
from mpl_toolkits.mplot3d import Axes3D
import time






def load_test_trajectory(filename,time_mult=1.0):
        if filename=='EKF.dat':
            e=0
            data  = np.loadtxt(filename, delimiter=' ', dtype='float')
            P_estimanda = []
            P_real = []
            time_trajectory=[]
            current_time = time.time()
            for i in range(len(data[:,0])):
                # print(data[i,1:3])
                P_estimanda.append(data[i,1:3])
                # print(data[i,3:])
                P_real.append(data[i,3:])
                
                time_trajectory.append(data[i,0])

            return(P_estimanda,time_trajectory,P_real,e)
        else:
            data  = np.loadtxt(filename, delimiter=' ', dtype='float')
            P_estimanda = []
            P_real = []
            time_trajectory=[]
            e=[]
            current_time = time.time()
            '''
            p0  = np.array([np.linalg.norm(p - l.p),
                np.arctan2(l.p[1] - p[1],
                           l.p[0] - p[0])], np.float32)
            '''
            
            
            for i in range(len(data[:,0])):
                # print(data[i,1:3])
                P_estimanda.append([np.linalg.norm(data[i,1:3]),
                                        np.arctan2(data[i,2] ,data[i,1])])
                # print(data[i,3:])
                P_real.append([np.linalg.norm(data[i,3:]),
                                        np.arctan2(data[i,4] ,data[i,3])])
                
                
                f = 3.0;
                S = np.array([[data[i,5],data[i,6]],[data[i,7],data[i,8]]])
                S=S[0:3,0:3]
                pearson = S[0, 1]/np.sqrt(S[0, 0] * S[1, 1])
                eigv = np.sqrt(1 + pearson)
                scale= np.sqrt(S[0, 0]) * f

                e.append(scale)
                
                
                time_trajectory.append(data[i,0])

            return(P_estimanda,time_trajectory,P_real,e)   
        
        
                    
def main(filename):
    P_estimanda,time_trajectory,P_real,e = load_test_trajectory(filename,time_mult=0.5)
    x_path, y_path= zip(*P_estimanda)
    x_path2, y_path2= zip(*P_real)
    x_path = np.array(x_path)
    y_path = np.array(y_path)
    x_path2 = np.array(x_path2)
    y_path2 = np.array(y_path2)

    Xerr=(x_path-x_path2)
    Yerr=(y_path-y_path2)
    XYerr=abs(Xerr-Yerr)/max(Xerr-Yerr)
  
    plt.style.use(['science','no-latex'])
    f=( 6,5)
  
    if filename=='EKF.dat': 
            # plt.set_aspect('equal', 'box')#ANHADIDO
            plt.figure(figsize=f)  
            plt.title('Evolución de las posiciones').set_fontsize(20)
            plt.xlabel("X")
            plt.ylabel("Y")
            plt.grid()
            plt.plot(x_path,y_path,color='red',label='Estimada')
            plt.plot(x_path2,y_path2,color='blue',label='Real')
            


            plt.legend(loc='center')
            plt.show()  
    else:
        # plt.figure().gca().set_aspect('equal', 'box')#ANHADIDO
        plt.figure(figsize=f)  
        plt.title('Evolución de la distancia').set_fontsize(20)
        plt.xlabel("t")
        plt.ylabel("d")
        plt.grid()
        plt.plot(x_path,color='red',label='Estimada')
        plt.plot(x_path2,color='blue',label='Real')
        plt.fill_between(np.arange(0,len(x_path2),1), x_path - e, x_path + e, alpha=0.2,color='red')#abs(Xerr-Yerr)/max(Xerr-Yerr)
        
        plt.legend(loc='center')
        plt.show()  
        
        plt.figure(figsize=f)  
        plt.title('Evolución del angulo').set_fontsize(20)
        plt.ylabel("angulo")
        plt.xlabel("t")
        plt.grid()
        plt.plot(y_path,color='red',label='Estimada')
        plt.plot(y_path2,color='blue',label='Real')
        plt.fill_between(np.arange(0,len(x_path2),1), y_path - e, y_path + e, alpha=0.2,color='red')
        plt.legend(loc='center')
        plt.show()  
        
        # fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        # ax.plot(y_path,x_path)#ang,d
        # ax.set_rmax(3)
        # ax.set_rticks([0.5, 1, 1.5, 2])  # Less radial ticks
        # ax.set_rlabel_position(-22.5)  # Move radial labels away from plotted line
        # ax.grid(True)
        # xT=plt.xticks()[0]
        # xL=['0',r'$\frac{\pi}{4}$',r'$\frac{\pi}{2}$',r'$\frac{3\pi}{4}$',\
        # r'$\pi$',r'$\frac{5\pi}{4}$',r'$\frac{3\pi}{2}$',r'$\frac{7\pi}{4}$']
        # plt.xticks(xT, xL)
        # ax.set_title("Trayectoria robot RB", va='bottom')
        # plt.show()
            
        
    
    plt.style.use(['science','no-latex'])
    f=( 6,3)
    plt.figure(figsize=f)     
    plt.title('Error entre posiciones').set_fontsize(20)
    plt.ylabel("error")
    plt.xlabel("tiempo")
    plt.ylim(top=8)
    plt.grid()
    plt.plot(abs(Xerr-Yerr)/max(Xerr-Yerr),color='red')
    plt.legend(loc='center')

    plt.show()     
# main(filename='EKFRB.dat')

