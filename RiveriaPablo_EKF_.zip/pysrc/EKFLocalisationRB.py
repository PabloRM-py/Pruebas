import numpy as np
from Simulator_ import Landmark, Map, Robot, EnvPlot
import math,keyboard,plot
# Create a map with random landmarks
try:
    noLandmarks = int(input('Nº landmarks pls:'))
except:
    noLandmarks=25
m = Map()
for i in range(noLandmarks):
    p = np.array([np.random.uniform(-5,5), np.random.uniform(-5,5)], np.float32)
    m.append(Landmark(p, i))

# Create an object to plot the environment (map), robot and estimate
e = EnvPlot()
    
# Set the state and measurement noise covariance
Q = np.array([[0.25**2, 0],[0, 0.25**2]], np.float32)
R = np.array([[0.2**2, 0],[0, (5 * np.pi / 180)**2]], np.float32)

# Create the robot object, by default measures the Cartesian
# coordinates of the landmarks in the environment
r = Robot(np.array([2,-2], np.float32), Q, R, type='rb', range=2.5)

class KF:
    def __init__(self, x0, P0, Q, R, m, dt = r.dt):
        self.dt = dt
        self.xk_k = x0
        self.Pk_k = P0
        self.Q = Q * self.dt
        self.R = R / self.dt
        self.type = type
        self.map = m
        pass
    
    def predict(self, u):
        # TODO: Implement the prediction step of the KF
        global x_k1,P_k1
        T=self.dt
        A=np.eye(2)
        B=T*np.eye(2)
        
        self.xk_k= A@self.xk_k +B@u
        self.Pk_k=A@self.Pk_k@A.T+self.Q
        pass
    
    def update(self, y):
        # TODO: Implement the updarte step of the KF for localization
        # using the field 'map' of the class
        L=[l.p for l in y]
        ID=[l.id for l in y]
        land= dict(zip(ID, L))
        if len(land)==0:self.Pk_k=self.Pk_k;self.xk_k=self.xk_k;print('N0 Landmark detected')
        else:
            print('-----------------------')
            y_hat=[]
            C=[]
            print('p(k): ', len(land))
            for l in land:
                           
                y_hat.append([np.sqrt(np.power(self.map[l].p[0]-self.xk_k[0],2)+np.power(self.map[l].p[1]-self.xk_k[1],2)),
                            math.atan2(self.map[l].p[1]-self.xk_k[1],self.map[l].p[0]-self.xk_k[0])]) 

            
                C.append([[(-self.map[l].p[0]+self.xk_k[0])/np.linalg.norm(self.map[l].p-self.xk_k),
                        (-self.map[l].p[1]+self.xk_k[1])/np.linalg.norm(self.map[l].p-self.xk_k)
                        ],
                        [(self.map[l].p[1]-self.xk_k[1])/np.power(np.linalg.norm(self.map[l].p-self.xk_k),2),
                        (-self.map[l].p[0]+self.xk_k[0])/np.power(np.linalg.norm(self.map[l].p-self.xk_k),2)
                        ]]) 
            y_hat=np.array(y_hat)
    
            C=np.array(C)
            y_hat.shape=(2*len(land))
            
            L=np.array(L)
            L.shape=(2*len(land))
            y_hat=L-y_hat

            C.shape=(2*len(land),2)

            R=np.kron(np.eye(len(land)),self.R)

        
            S=C@self.Pk_k@C.T+R

            K=self.Pk_k@C.T@np.linalg.inv(S)
            

        
            if len(land)==1:
                print(self.xk_k)       
       
       
        

            self.Pk_k=self.Pk_k-K@S@K.T
            self.xk_k=self.xk_k+K@y_hat
                
        pass
    
# Initial estimates of the position of the error and its covariance
# matrix
xHat = np.array([0, 0], np.float32)
PHat = np.array([[3,0],[0,3]], np.float32)

# Object for the (Extended) Kalman filter estimator
kf = KF(xHat, PHat, Q,  R, m)
        
# Plot the first step of the estimation process and pause
e.plotSim(r, m, kf, True)

# Main loop:
# 1- The robot moves (action) and returns its velocity
# 2- Predict step of the Kalman filter
# 3- The robot perceives the environment (landmarks) and
#    returns a list of landmarks
# 4- Update state of the Kalman filter
fd = open('EKFRB.dat', 'w')
while r.t < r.tf:
    u = r.action()
    kf.predict(u)#                                                         5               6            7                8
    fd.write(F'{r.t} {kf.xk_k[0]} {kf.xk_k[1]} {r.p[0]} {r.p[1]} {kf.Pk_k[0][0]} {kf.Pk_k[0][1]} {kf.Pk_k[1][0]} {kf.Pk_k[1][1]}\n')
    y = r.measure(m)
    kf.update(y)
    
    e.plotSim(r, m, kf)
    try:  # used try so that if user pressed other than the given key error will not be shown
        if keyboard.is_pressed('w'):  # if key 'q' is pressed 
            print('You Pressed A Key!')
            break  # finishing the loop
    except:
        break  
fd.close()      

plot.main(filename='EKFRB.dat')

