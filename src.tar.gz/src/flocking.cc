

#include "flocking.hh"
#include<tuple>
const int numeroRobots(40);
const int MAXIMO(1e6);

const bool separation=0;
const bool alignment=1;
const bool cohesion=0;

// TODO: Implement here your flocking robot
std::vector<float>FS(2);
std::vector<Eigen::Matrix<float,2,1>>vector_A;
std::vector<float>FC(2);


FlockingRobot::FlockingRobot(unsigned int id, const mrs::Position2d & p, 
		const mrs::RobotSettings & settings,
		const mrs::Velocity2d & vel ):
        mrs::Robot(id,p,settings){

            m_vel=vel;
            m_settings=settings;
            m_pos=p;
        }

mrs::RobotPtr FlockingRobot::clone() const
  { 
    mrs:: RobotPtr newRobot = std::make_shared<FlockingRobot>(m_id, m_pos, m_settings,m_vel);

    
    return newRobot;
  }

const mrs::Velocity2d & FlockingRobot::action(const std::vector<mrs::RobotPtr> & swarm) 
  {

  if (swarm.size()>=1 and swarm.size()<20){


    }
    
    /***************************/
    //separation

    float d=0;
    float ang=0;
    float x,y;
    
    for (unsigned int ii=0; ii<swarm.size();ii++){
      d=mrs::distance(m_pos,swarm[ii]->position());
      ang=mrs::angle(m_pos,swarm[ii]->position());
      FS[0]=-(1/d)*(std::cos(ang));
      FS[1]=-(1/d)*(std::sin(ang));
    }
    /***************************/
    

    /*************************/
    //cohesion

    std::vector<float>x1(swarm.size());
    std::vector<float>y1(swarm.size());
    for (unsigned int ii=0; ii<swarm.size();ii++){

      x1[ii]=swarm[ii]->position()[0];
      y1[ii]=swarm[ii]->position()[1];
    }

    float X=0;
    float Y=0;
    for (unsigned int i=0;i<x1.size();i++){
      X=X+x1[i];
      Y=Y+y1[i];
    }

    std::vector<float>FC(2);
    FC[0]=(X/swarm.size())-m_pos[0];
    FC[1]=(Y/swarm.size())-m_pos[1];

    /***************************/


    /***************************/
    //alignment
    std::vector<Eigen::Matrix<float,2,1>>vector_A;
    for (unsigned int ii=0; ii<swarm.size();ii++){
      vector_A.push_back(swarm[ii]->velocity());
    

    //m_vel=-mrs::average(vector_A);

    /*************************/
    
if((separation) and (cohesion) and (alignment))//todo
{
  x=FS[0]+mrs::average(vector_A)[0]+FC[0];
  y=FS[1]+mrs::average(vector_A)[1]+FC[1];
}
if((separation) and not(cohesion) and not(alignment))//S
{
  x=FS[0];
  y=FS[1];
}
if(not(separation) and not(cohesion) and (alignment))//A
{
  x=mrs::average(vector_A)[0];
  y=mrs::average(vector_A)[1];
}
if(not(separation) and (cohesion) and not(alignment))//C
{
  x=FC[0];
  y=FC[1];
}


  //m_vel=mrs::Velocity2d(mrs::average(vector_A3)[0],mrs::average(vector_A3)[1]);
  m_vel=mrs::Velocity2d(x,y);
  
  

  return m_vel;
    
    }





      
  }
